local AG=AleeGather
local floor=math.floor
function AG:InitializeDatabase() end

function AG:PackCoord(x,y)
  return floor(x*10000+0.5)*10000 + floor(y*10000+0.5)
end

function AG:UnpackCoord(p)
  local xi=floor(p/10000)
  local yi=p-xi*10000
  return xi/10000, yi/10000
end

function AG:DistanceYards(zone,x1,y1,x2,y2)
  local s=self.ZoneSize[zone]
  if not s then return nil end
  local dx=(x2-x1)*s[1]
  local dy=(y2-y1)*s[2]
  return math.sqrt(dx*dx+dy*dy)
end

AG.professionSpells = {
  ["Mining"] = 2575,
  ["Herb Gathering"] = 2366,
  ["Fishing"] = 7620,
  ["Extract Gas"] = 4036, -- Engineering; gas extraction also needs the extractor item in-game.
}

function AG:InvalidateProfessionCache()
  self._professionCache=nil
end

function AG:BuildProfessionCache()
  local cache={}
  local names={}
  for category,spellID in pairs(self.professionSpells) do
    local spellName,_,spellIcon=GetSpellInfo(spellID)
    if spellName then names[string.lower(spellName)]={category=category,icon=spellIcon} end
  end
  -- Fallback names for clients with unusual locale data.
  names["mining"]={category="Mining"}; names["minería"]={category="Mining"}; names["mineria"]={category="Mining"}
  names["herbalism"]={category="Herb Gathering"}; names["herboristería"]={category="Herb Gathering"}; names["herboristeria"]={category="Herb Gathering"}
  names["fishing"]={category="Fishing"}; names["pesca"]={category="Fishing"}
  names["engineering"]={category="Extract Gas"}; names["ingeniería"]={category="Extract Gas"}; names["ingenieria"]={category="Extract Gas"}

  for i=1,GetNumSkillLines() do
    local name,_,_,rank,_,_,maxRank = GetSkillLineInfo(i)
    if name then
      local hit=names[string.lower(name)]
      if hit then
        local info=cache[hit.category] or {}
        info.name=name
        info.rank=rank or 0
        info.maxRank=maxRank or 0
        info.icon=hit.icon or select(3,GetSpellInfo(self.professionSpells[hit.category] or 0))
        cache[hit.category]=info
      end
    end
  end
  self._professionCache=cache
  return cache
end

function AG:GetProfessionInfo(category)
  local cache=self._professionCache or self:BuildProfessionCache()
  return cache[category]
end

function AG:HasProfessionForCategory(category)
  if category=="Treasure" then return true end
  return self:GetProfessionInfo(category)~=nil
end

function AG:IsCategoryAllowedByProfession(cat)
  if not self.db or not self.db.profile.autoProfessionFilter then return true end
  return self:HasProfessionForCategory(cat)
end

function AG:IsCategoryEnabled(cat)
  if not self.db or self.db.profile.categories[cat] == false then return false end
  return self:IsCategoryAllowedByProfession(cat)
end

function AG:GetProfessionSkill(category)
  local info=self:GetProfessionInfo(category)
  return info and info.rank or nil
end

function AG:PassesSkillFilter(id)
  if not self.db.profile.showOnlySkill then return true end
  local n=self.Nodes[id]
  if not n or not n.skill or n.skill<=0 then return true end
  local skill=self:GetProfessionSkill(n.category)
  if not skill then return true end
  return skill>=n.skill
end

function AG:GetNodeRecord(zone,packed)
  local z=self.db and self.db.nodes and self.db.nodes[zone]
  return z and z[packed]
end

function AG:GetNodeState(rec)
  if type(rec)~="table" then return "available" end
  if rec.depletedUntil and rec.depletedUntil>time() then return "depleted" end
  return "available"
end

function AG:SetNodeState(zone,packed,state)
  local z=self.db.nodes[zone]
  if not z then return end
  local rec=z[packed]
  if type(rec)~="table" then
    rec={id=rec}
    z[packed]=rec
  end
  if state=="depleted" then
    rec.depletedUntil=time()+(tonumber(self.db.profile.depletedSeconds) or 300)
  else
    rec.depletedUntil=nil
  end
end

function AG:FindNearestNode(zone,id,x,y,maxDist)
  local z=self.db.nodes[zone]
  if not z then return nil,nil end
  local best,bestDist
  for p,rec in pairs(z) do
    local rid=type(rec)=="table" and rec.id or rec
    if rid==id then
      local ox,oy=self:UnpackCoord(p)
      local d=self:DistanceYards(zone,x,y,ox,oy)
      if d and d<=(maxDist or 25) and (not bestDist or d<bestDist) then
        best,bestDist=p,d
      end
    end
  end
  return best,bestDist
end

function AG:RecordSessionGather(category,name)
  if not self.session or self.session.paused then return end
  self.session.total=(self.session.total or 0)+1
  self.session.counts[category]=(self.session.counts[category] or 0)+1
  self.session.last=name or "-"
end

function AG:AddNode(id,zone,x,y,source)
  if not id or not zone or not x or not y then return false,nil end
  local node=self.Nodes[id]
  if not node then return false,nil end
  self:RecordSessionGather(node.category,self:GetNodeName(id))
  local z=self.db.nodes[zone]
  if not z then z={} self.db.nodes[zone]=z end

  local nearby=self:FindNearestNode(zone,id,x,y,18)
  if nearby then
    local rec=z[nearby]
    if type(rec)~="table" then rec={id=id}; z[nearby]=rec end
    rec.seen=time()
    rec.count=(rec.count or 1)+1
    rec.source=source or rec.source
    rec.depletedUntil=nil
    if self.db.profile.debug then self:Print(self:L("DUPLICATE").." "..self:GetNodeName(id)) end
    return false,nearby
  end

  local p=self:PackCoord(x,y)
  z[p]={id=id,seen=time(),count=1,source=source or "learned"}
  if self.db.profile.debug then self:Print(self:L("LEARNED")..": "..self.session.last) end
  if self.RefreshAll then self:RefreshAll() end
  return true,p
end

function AG:MarkNodeDepleted(zone,id,x,y)
  if not zone or not id or not x or not y then return end
  local p=self:FindNearestNode(zone,id,x,y,30)
  if p then
    self:SetNodeState(zone,p,"depleted")
    if self.RefreshAll then self:RefreshAll() end
  end
end

function AG:MarkNodeAvailable(zone,id,x,y)
  if not zone or not id or not x or not y then return end
  local p=self:FindNearestNode(zone,id,x,y,30)
  if p then self:SetNodeState(zone,p,"available") end
end

function AG:ClearDatabase()
  self.db.nodes={}
  AleeGatherDB.nodes=self.db.nodes
  self:Print(self:L("DB_CLEARED"))
  self:RefreshAll()
end
