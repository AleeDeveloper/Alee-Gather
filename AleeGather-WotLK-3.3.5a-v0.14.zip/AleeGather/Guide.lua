local AG=AleeGather

AG.GuideData = {
  Mining = {
    {min=1,max=64,nodes={201},zonesEN="Elwynn Forest, Dun Morogh, Durotar, Mulgore, Tirisfal Glades, Darkshore",zonesES="Bosque de Elwynn, Dun Morogh, Durotar, Mulgore, Claros de Tirisfal, Costa Oscura"},
    {min=65,max=124,nodes={202,204,201},zonesEN="Hillsbrad Foothills, Redridge Mountains, Ashenvale, The Barrens",zonesES="Laderas de Trabalomas, Montañas Crestagrana, Vallefresno, Los Baldíos"},
    {min=125,max=174,nodes={203,205},zonesEN="Arathi Highlands, Desolace, Thousand Needles",zonesES="Tierras Altas de Arathi, Desolace, Las Mil Agujas"},
    {min=175,max=244,nodes={206,208},zonesEN="The Hinterlands, Tanaris",zonesES="Tierras del Interior, Tanaris"},
    {min=245,max=274,nodes={214,206,208},zonesEN="Un'Goro Crater, Blasted Lands, Felwood",zonesES="Cráter de Un'Goro, Las Tierras Devastadas, Frondavil"},
    {min=275,max=299,nodes={215,214},zonesEN="Un'Goro Crater, Eastern Plaguelands, Winterspring, Burning Steppes",zonesES="Cráter de Un'Goro, Tierras de la Peste del Este, Cuna del Invierno, Estepas Ardientes"},
    {min=300,max=324,nodes={221},zonesEN="Hellfire Peninsula",zonesES="Península del Fuego Infernal"},
    {min=325,max=349,nodes={222},zonesEN="Zangarmarsh, Terokkar Forest",zonesES="Marisma de Zangar, Bosque de Terokkar"},
    {min=350,max=399,nodes={228,229},zonesEN="Borean Tundra, Howling Fjord",zonesES="Tundra Boreal, Fiordo Aquilonal"},
    {min=400,max=450,nodes={231,232,230},zonesEN="Sholazar Basin, The Storm Peaks",zonesES="Cuenca de Sholazar, Las Cumbres Tormentosas"},
  },
  ["Herb Gathering"] = {
    {min=1,max=69,nodes={401,402,403},zonesEN="Any starter zone",zonesES="Cualquier zona inicial"},
    {min=70,max=114,nodes={404,407,408},zonesEN="The Barrens, Silverpine Forest, Loch Modan, Darkshore",zonesES="Los Baldíos, Bosque de Argénteos, Loch Modan, Costa Oscura"},
    {min=115,max=169,nodes={409,410,408,411,412},zonesEN="Hillsbrad Foothills, Wetlands, Stonetalon Mountains",zonesES="Laderas de Trabalomas, Los Humedales, Sierra Espolón"},
    {min=170,max=204,nodes={411,412,413,414,415},zonesEN="Stranglethorn Vale, Arathi Highlands",zonesES="Vega de Tuercespina, Tierras Altas de Arathi"},
    {min=205,max=229,nodes={417,418},zonesEN="Tanaris, Searing Gorge",zonesES="Tanaris, La Garganta de Fuego"},
    {min=230,max=269,nodes={421,422,423,424,425},zonesEN="Feralas, The Hinterlands",zonesES="Feralas, Tierras del Interior"},
    {min=270,max=299,nodes={426,427,428,429},zonesEN="Felwood, Western Plaguelands, Eastern Plaguelands",zonesES="Frondavil, Tierras de la Peste del Oeste, Tierras de la Peste del Este"},
    {min=300,max=349,nodes={431,432,433,434,435},zonesEN="Hellfire Peninsula, Zangarmarsh, Terokkar Forest, Nagrand",zonesES="Península del Fuego Infernal, Marisma de Zangar, Bosque de Terokkar, Nagrand"},
    {min=350,max=399,nodes={438,440,441,450},zonesEN="Borean Tundra, Howling Fjord, Dragonblight",zonesES="Tundra Boreal, Fiordo Aquilonal, Cementerio de Dragones"},
    {min=400,max=434,nodes={442,443,451},zonesEN="Sholazar Basin, Zul'Drak",zonesES="Cuenca de Sholazar, Zul'Drak"},
    {min=435,max=450,nodes={447,448},zonesEN="The Storm Peaks, Icecrown",zonesES="Las Cumbres Tormentosas, Corona de Hielo"},
  },
}

local function getStagesForCurrentProfession()
  local mining=AG:GetProfessionInfo("Mining")
  local herb=AG:GetProfessionInfo("Herb Gathering")
  if mining then return "Mining",mining.rank or 0 end
  if herb then return "Herb Gathering",herb.rank or 0 end
  return nil,0
end

local function nodeList(ids)
  local out={}
  for _,id in ipairs(ids or {}) do
    if AG.Nodes[id] then table.insert(out,AG:GetNodeName(id)) end
  end
  return table.concat(out,", ")
end

function AG:GetGuideStage(category,skill)
  local data=self.GuideData[category]
  if not data then return nil end
  for _,stage in ipairs(data) do
    if skill>=stage.min and skill<=stage.max then return stage end
  end
  return data[#data]
end

function AG:InitializeGuide()
  local f=CreateFrame("Frame","AleeGatherGuide",UIParent)
  self.guide=f
  f:SetWidth(410); f:SetHeight(260); f:SetPoint("CENTER",UIParent,"CENTER",0,40)
  f:SetFrameStrata("DIALOG")
  f:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=32,insets={left=11,right=12,top=12,bottom=11}})
  f:EnableMouse(true); f:SetMovable(true); f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart",function(self) self:StartMoving() end)
  f:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
  f:Hide()

  f.title=f:CreateFontString(nil,"OVERLAY","GameFontNormalLarge"); f.title:SetPoint("TOPLEFT",24,-22)
  f.prof=f:CreateFontString(nil,"OVERLAY","GameFontHighlight"); f.prof:SetPoint("TOPLEFT",24,-55); f.prof:SetWidth(360); f.prof:SetJustifyH("LEFT")
  f.range=f:CreateFontString(nil,"OVERLAY","GameFontNormal"); f.range:SetPoint("TOPLEFT",24,-82); f.range:SetWidth(360); f.range:SetJustifyH("LEFT")
  f.nodes=f:CreateFontString(nil,"OVERLAY","GameFontHighlight"); f.nodes:SetPoint("TOPLEFT",24,-112); f.nodes:SetWidth(360); f.nodes:SetJustifyH("LEFT")
  f.zones=f:CreateFontString(nil,"OVERLAY","GameFontHighlight"); f.zones:SetPoint("TOPLEFT",24,-153); f.zones:SetWidth(360); f.zones:SetJustifyH("LEFT"); f.zones:SetJustifyV("TOP")
  f.note=f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall"); f.note:SetPoint("BOTTOMLEFT",24,42); f.note:SetWidth(350); f.note:SetJustifyH("LEFT")

  f.close=CreateFrame("Button",nil,f,"UIPanelButtonTemplate"); f.close:SetWidth(90); f.close:SetHeight(22); f.close:SetPoint("BOTTOMRIGHT",-24,16)
  f.close:SetScript("OnClick",function() f:Hide() end)
end

function AG:RefreshGuide()
  if not self.guide then self:InitializeGuide() end
  local category,skill=getStagesForCurrentProfession()
  local f=self.guide
  f.title:SetText("|cff55dd88"..self:L("GUIDE_TITLE").."|r")
  f.close:SetText(self:L("CLOSE"))
  if not category then
    f.prof:SetText(self:L("GUIDE_NO_PROF"))
    f.range:SetText("")
    f.nodes:SetText("")
    f.zones:SetText("")
    f.note:SetText(self:L("GUIDE_LIGHT"))
    return
  end
  local stage=self:GetGuideStage(category,skill)
  f.prof:SetText(self:L("PROFESSIONS")..": |cffffffff"..self:L(self.categoryKeys[category]).." "..skill.."|r")
  f.range:SetText(self:L("GUIDE_RANGE")..": |cffffcc55"..stage.min.." - "..stage.max.."|r")
  f.nodes:SetText(self:L("GUIDE_NODES")..": |cffffffff"..nodeList(stage.nodes).."|r")
  local lang=self:GetLanguage()
  local zones=(lang=="enUS") and stage.zonesEN or stage.zonesES
  f.zones:SetText(self:L("GUIDE_ZONES")..":\n|cffffffff"..zones.."|r")
  f.note:SetText(self:L("GUIDE_LIGHT"))
end

function AG:ToggleGuide()
  if not self.guide then self:InitializeGuide() end
  if self.guide:IsShown() then
    self.guide:Hide()
  else
    self:RefreshGuide()
    self.guide:Show()
  end
end
