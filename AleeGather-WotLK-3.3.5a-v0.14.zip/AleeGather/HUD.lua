local AG=AleeGather
local cats={"Herb Gathering","Mining","Fishing","Extract Gas","Treasure"}

local function fmtTime(sec)
  sec=math.max(0,math.floor(sec or 0))
  return string.format("%02d:%02d:%02d",math.floor(sec/3600),math.floor((sec%3600)/60),sec%60)
end

function AG:SessionElapsed()
  if not self.session then return 0 end
  local now=self.session.paused and self.session.pauseAt or GetTime()
  return now-self.session.start-self.session.pausedTotal
end

function AG:ResetSession()
  self.session.start=GetTime(); self.session.paused=false; self.session.pauseAt=0; self.session.pausedTotal=0
  self.session.total=0; self.session.last="-"
  for _,c in ipairs(cats) do self.session.counts[c]=0 end
  self:RefreshHUD()
end

function AG:ToggleSessionPause()
  if self.session.paused then
    self.session.pausedTotal=self.session.pausedTotal+(GetTime()-self.session.pauseAt)
    self.session.paused=false
  else
    self.session.paused=true; self.session.pauseAt=GetTime()
  end
  self:RefreshHUD()
end

local function makeSmallButton(parent,width,label,callback)
  local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
  b:SetWidth(width); b:SetHeight(20); b:SetText(label or "")
  b:SetScript("OnClick",callback)
  return b
end

function AG:InitializeHUD()
  local f=CreateFrame("Frame","AleeGatherHUD",UIParent)
  self.hud=f
  f:SetWidth(304); f:SetHeight(194)
  f:SetPoint("TOPLEFT",UIParent,"TOPLEFT",self.db.profile.hud.x,self.db.profile.hud.y)
  f:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
    tile=true,tileSize=16,edgeSize=12,insets={left=3,right=3,top=3,bottom=3}})
  f:SetBackdropColor(0.03,0.05,0.07,0.90)
  f:EnableMouse(true); f:SetMovable(true); f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart",function(self) if not AG.db.profile.hud.locked then self:StartMoving() end end)
  f:SetScript("OnDragStop",function(self)
    self:StopMovingOrSizing()
    local l,t=self:GetLeft(),self:GetTop()
    if l and t then AG.db.profile.hud.x=l; AG.db.profile.hud.y=t-UIParent:GetHeight() end
  end)

  f.title=f:CreateFontString(nil,"OVERLAY","GameFontNormalLarge"); f.title:SetPoint("TOPLEFT",12,-9)
  f.time=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); f.time:SetPoint("TOPRIGHT",-12,-11)

  f.prof=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
  f.prof:SetPoint("TOPLEFT",12,-31); f.prof:SetWidth(280); f.prof:SetJustifyH("LEFT")

  local sessionIcons={
    ["Herb Gathering"]="Interface\\Icons\\Trade_Herbalism",
    ["Mining"]="Interface\\Icons\\Trade_Mining",
    ["Fishing"]="Interface\\Icons\\Trade_Fishing",
    ["Extract Gas"]="Interface\\Icons\\Trade_Engineering",
    ["Treasure"]="Interface\\Icons\\INV_Misc_Bag_10",
  }
  f.lines={}; f.catButtons={}
  for i,c in ipairs(cats) do
    local y=-51-(i-1)*20
    local b=CreateFrame("Button",nil,f)
    b:SetWidth(18); b:SetHeight(18); b:SetPoint("TOPLEFT",12,y+2)
    b.icon=b:CreateTexture(nil,"ARTWORK"); b.icon:SetAllPoints(b); b.icon:SetTexture(sessionIcons[c] or AG.categoryIcons[c])
    b.category=c
    b:SetScript("OnClick",function(self)
      local cat=self.category
      AG.db.profile.categories[cat]=not (AG.db.profile.categories[cat]~=false)
      AG:RefreshAll()
    end)
    b:SetScript("OnEnter",function(self)
      GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
      GameTooltip:AddLine(AG:L(AG.categoryKeys[self.category]),1,1,1)
      if AG.db.profile.categories[self.category]~=false then
        GameTooltip:AddLine(AG:L("CLICK_HIDE_CATEGORY"),0.8,0.8,0.8)
      else
        GameTooltip:AddLine(AG:L("CLICK_SHOW_CATEGORY"),0.8,0.8,0.8)
      end
      if AG.db.profile.autoProfessionFilter and not AG:HasProfessionForCategory(self.category) and self.category~="Treasure" then
        GameTooltip:AddLine(AG:L("FILTERED_BY_PROFESSION"),1,0.65,0.2)
      end
      GameTooltip:Show()
    end)
    b:SetScript("OnLeave",function() GameTooltip:Hide() end)
    f.catButtons[c]=b

    local fs=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    fs:SetPoint("TOPLEFT",36,y); fs:SetJustifyH("LEFT")
    f.lines[c]=fs
  end

  f.last=f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
  f.last:SetPoint("TOPLEFT",12,-153); f.last:SetWidth(280); f.last:SetJustifyH("LEFT")

  f.pause=makeSmallButton(f,62,"",function() AG:ToggleSessionPause() end)
  f.pause:SetPoint("BOTTOMLEFT",10,9)
  f.reset=makeSmallButton(f,62,"",function() AG:ResetSession() end)
  f.reset:SetPoint("LEFT",f.pause,"RIGHT",6,0)
  f.radarButton=makeSmallButton(f,68,"",function()
    AG.db.profile.radar.enabled=not AG.db.profile.radar.enabled
    AG:RefreshAll()
  end)
  f.radarButton:SetPoint("LEFT",f.reset,"RIGHT",6,0)
  f.guideButton=makeSmallButton(f,28,"",function() if AG.ToggleGuide then AG:ToggleGuide() end end)
  f.guideButton:SetPoint("LEFT",f.radarButton,"RIGHT",6,0)
  f.guideButton:SetScript("OnEnter",function(self)
    GameTooltip:SetOwner(self,"ANCHOR_TOP")
    GameTooltip:AddLine(AG:L("GUIDE"),1,1,1)
    GameTooltip:AddLine("/ag guide",0.75,0.85,1)
    GameTooltip:Show()
  end)
  f.guideButton:SetScript("OnLeave",function() GameTooltip:Hide() end)

  local elapsed=0
  f:SetScript("OnUpdate",function(_,e) elapsed=elapsed+e; if elapsed>1 then elapsed=0; AG:RefreshHUD() end end)
  self:RefreshHUD()
end

function AG:GetProfessionHUDText()
  local parts={}
  local order={"Herb Gathering","Mining","Fishing","Extract Gas"}
  for _,cat in ipairs(order) do
    local info=self:GetProfessionInfo(cat)
    if info then
      local tex=info.icon and ("|T"..info.icon..":14:14:0:0|t ") or ""
      table.insert(parts,tex..self:L(self.categoryKeys[cat]).." "..tostring(info.rank or 0))
    end
  end
  if #parts==0 then return self:L("PROF_NONE") end
  return table.concat(parts,"  ")
end

function AG:RefreshHUD()
  if not self.hud or not self.db then return end
  if self.db.profile.showHUD then self.hud:Show() else self.hud:Hide(); return end
  self.hud.title:SetText("|cff55dd88"..self:L("SESSION").."|r  |cffffcc55"..self.session.total.."|r")
  self.hud.time:SetText((self.session.paused and "|cffff5555"..self:L("PAUSED").."|r  " or "")..fmtTime(self:SessionElapsed()))
  self.hud.prof:SetText("|cffb8d7ff"..self:L("PROFESSIONS")..":|r "..self:GetProfessionHUDText())
  for _,c in ipairs(cats) do
    local manuallyOn=self.db.profile.categories[c]~=false
    local profAllowed=self:IsCategoryAllowedByProfession(c)
    local enabled=manuallyOn and profAllowed
    local prefix=enabled and "|cffffffff" or "|cff777777"
    local suffix="|r"
    self.hud.lines[c]:SetText(prefix..self:L(self.categoryKeys[c])..": "..(self.session.counts[c] or 0)..suffix)
    local b=self.hud.catButtons[c]
    if b and b.icon then
      local sessionIcons={
        ["Herb Gathering"]="Interface\\Icons\\Trade_Herbalism",
        ["Mining"]="Interface\\Icons\\Trade_Mining",
        ["Fishing"]="Interface\\Icons\\Trade_Fishing",
        ["Extract Gas"]="Interface\\Icons\\Trade_Engineering",
        ["Treasure"]="Interface\\Icons\\INV_Misc_Bag_10",
      }
      b.icon:SetTexture(sessionIcons[c] or self.categoryIcons[c])
      b.icon:SetAlpha(enabled and 1.0 or 0.28)
    end
  end
  self.hud.last:SetText(self:L("LAST")..": "..(self.session.last or "-"))
  self.hud.pause:SetText(self.session.paused and self:L("RESUME") or self:L("PAUSE"))
  self.hud.reset:SetText(self:L("RESET_SHORT"))
  self.hud.radarButton:SetText((self.db.profile.radar.enabled and "|cff55ff66" or "|cff888888").."Radar|r")
  if self.hud.guideButton then self.hud.guideButton:SetText("G") end
end
