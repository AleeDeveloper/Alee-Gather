-- AleeGather WotLK 3.3.5a seed database.
-- The core addon is fully functional without this file and learns nodes as you gather.
-- A large externally sourced coordinate database is intentionally kept separate so
-- it can be regenerated/replaced without touching the engine.
AleeGatherSeed = AleeGatherSeed or {}
