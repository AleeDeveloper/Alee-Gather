# AleeGather — WotLK 3.3.5a / Warmane

Native standalone gathering tracker for the original WoW 3.3.5a client (build 12340).

## v0.3 highlights
- Per-node artwork imported from the user-supplied WotLK GatherMate package:
  - individual ore textures (Copper, Tin, Iron, Mithril, Thorium, Cobalt, Saronite, Titanium...)
  - individual herb textures
  - fishing pool, gas cloud, and treasure textures
- Green/red status ring around each node:
  - Green = known node / not harvested by you recently
  - Red = harvested by you recently and treated as probably depleted
  - The red timeout is configurable (1–15 min)
- World-map pins, minimap pins, and farming radar all use the same node artwork/status.
- Safer collector:
  - Smelting is no longer treated as Mining.
  - A node is saved only after a gathering interaction is followed by LOOT_OPENED.
  - Error messages no longer create new database coordinates.
- Farming radar + farming session HUD.
- Interface configuration under Esc -> Interface -> AddOns -> AleeGather.
- English, Spanish (Spain), Spanish (Mexico/LatAm).
- No Ace3 dependency.

## Important limitation of WoW 3.3.5a
The old client does not expose a complete API telling an addon whether every database node is currently spawned on the server.
AleeGather therefore uses the status ring as a practical local state:
green = known/not recently harvested; red = recently harvested by you.
Seeing/interacting with the actual world object immediately resets that point to green.

## Commands
/ag
/ag radar
/ag hud
/ag reset
/ag import
/ag debug

## Importing a full 3.3.5a database
AleeGather can import the classic GatherMate_Data globals directly.
The GatherMate addon itself does not have to work: if GatherMate_Data is installed, `/ag import`
tries to load it and copies compatible points into AleeGather's own SavedVariables.

## Artwork attribution
The per-node TGA artwork and original GatherMate icon/track texture in this build were taken
from the GatherMate package supplied by the user for this conversion. The accompanying
GatherMate license is included as GATHERMATE-LICENSE.txt.


## v0.4 additions
- Session HUD buttons: Pause/Resume, Reset, Radar toggle.
- Clickable category icons in the session HUD to show/hide Herb, Mining, Fishing, Gas and Treasure.
- Automatic profession detection from the 3.3.5a skill lines.
- Optional automatic profession filter: Herbalism shows herbs, Mining shows ore, Fishing shows pools, Engineering shows gas; Treasure stays available.
- Profession icons and current skill ranks are shown in the session HUD.
- Green status now explicitly means known / estimated available; it is not a live server spawn check.

## v0.5
- Radar orientation now mirrors the actual minimap orientation.
- Radar zoom +/- controls.
- Radar window size S-/S+ controls.
- World map/minimap/radar pins use interactive buttons with higher frame level for reliable tooltips.
- Tooltips show node name and required gathering level.
- Session category buttons use real representative gathering-node artwork.
- Farming radar session button widened so localized text does not overflow.

## v0.6
- World-map pins promoted to a reliable interactive layer for mouse tooltips.
- Map/minimap/radar tooltip: node name + required gathering level.
- Session Mining button now uses the pickaxe profession icon.
- Added lightweight in-game Mining/Herbalism guide (`/ag guide`).
- Guide automatically detects profession skill and recommends the current bracket, node types and zones.
- Radar player arrow now uses AleeGather's own north-facing 2D arrow, avoiding the 3.3.5a MinimapArrow model offset.
- Radar arrow follows fixed/rotating minimap behavior.

## v0.7
- Fixed radar player-arrow direction to match the 3.3.5a minimap.
- Radar performance pass: arrow updates independently at 10 Hz; node scan/placement at 4 Hz.
- Radar only recalculates arrow texture coordinates when facing changes meaningfully.
- Compact session HUD restored; Guide is now a small `G` button with tooltip.
- Removed obsolete radar-sync option and related dead configuration code.
- Restored `/ag guide` and `/ag guia` command routing.
- General cleanup for a future public release.

## v0.8
- Radar player arrow removed; a fixed center dot is used instead.
- Session button simplified to `Radar`.
- Removed radar-arrow update work entirely.
- Config window lower section reorganized to avoid overlapping labels/controls.
- Minimap button now respects external button collectors: if another addon reparents it, AleeGather stops repositioning it.
- Added a generic world-map cursor proximity tooltip fallback for Leatrix Maps and similar map addons that intercept mouse input.

## v0.9
- Removed unintended white status-ring artifacts from recycled pins.
- Status rings are now strictly green (available/estimated) or black (depleted/local state).
- When status rings are disabled, no ring texture is rendered at all.
- World-map hover now uses cursor coordinates relative to WorldMapButton instead of pin mouse events, improving compatibility with Leatrix Maps.

## v0.12
- Minimap rendering reverted to the v0.9 update model; v0.10/v0.11 zoom/pool experiments removed.
- Minimap node pins are now plain Frames instead of Buttons to avoid DragonflightUI/MBB-style automatic button borders.
- Node TGA alpha was cleaned to remove low-alpha square haze from legacy GatherMate artwork.
- Minimap node size is fixed at 16 px × configured scale.
- Status rings use separate baked green/black textures; no white status texture is used.

## v0.14
- Removed all Leatrix Maps-specific world-map hover compatibility.
- World-map pins are display-only and never capture mouse input.
- Fixed map browsing: AleeGather no longer calls SetMapToCurrentZone while the world map is open.
- Player position is cached while browsing other zones, restoring normal right-click region/continent navigation.
